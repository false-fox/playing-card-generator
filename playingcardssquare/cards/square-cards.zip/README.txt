2024-05-03 false-fox @ falsefox.dev - GPL 3.0 License

https://github.com/false-fox/playing-card-generator